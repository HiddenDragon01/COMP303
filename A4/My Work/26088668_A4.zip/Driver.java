import java.io.File;

public class Driver {


    public static void main(String[] args) throws CloneNotSupportedException {

        /**
         * Q1:
         */

         /** Create Library **/

        WatchListFilter firstFilter = new FirstEpisodeFilter();
        WatchListFilter studioFilter = new FilterWatchListStudio("WarnerBrothers");
        WatchListFilter englishFilter = new LanguageFilterStrategy(Language.ENGLISH);
        WatchListFilter frenchFilter = new LanguageFilterStrategy(Language.FRENCH);

        DisjunctionWatchListFilter bilingualFilter = new DisjunctionWatchListFilter();
        bilingualFilter.addFilter(englishFilter);
        bilingualFilter.addFilter(frenchFilter);

        ConjunctionWatchListFilter conjunctionFilter = new ConjunctionWatchListFilter();

        conjunctionFilter.addFilter(firstFilter);
        conjunctionFilter.addFilter(studioFilter);
        conjunctionFilter.addFilter(bilingualFilter);

        Library sampleLibrary = new Library();

        File f1 = new File ("12345");
        String Title1 = "Zelda";
        Language lang1 = Language.FRENCH;
        String Studio1 = "Mario";
        Movie m1 = new Movie(f1, Title1, lang1, Studio1);
        File f2 = new File ("54321");
        String Title2 = "Earthlings";
        Language lang2 = Language.ENGLISH;
        String Studio2 = "Luigi";
        Movie m2 = new Movie(f2, Title2, lang2, Studio2);
        sampleLibrary.addMovie(m1);
        sampleLibrary.addMovie(m2);

        String Title3 = "Lupin";
        Language lang3 = Language.FRENCH;
        String Studio3 = "Assane";
        TVShow t1 = new TVShow(Title3, lang3, Studio3);
        String Title4 = "Titans";
        Language lang4 = Language.FRENCH;
        String Studio4 = "WarnerBrothers";
        TVShow t2 = new TVShow(Title4, lang4, Studio4);
        String Title5 = "Batwoman";
        Language lang5 = Language.ENGLISH;
        String Studio5 = "WarnerBrothers";
        TVShow t3 = new TVShow(Title5, lang5, Studio5);
        String Title6 = "Katy Keene";
        Language lang6 = Language.ANCIENT_GREEK;
        String Studio6 = "WarnerBrothers";
        TVShow t4 = new TVShow(Title6, lang6, Studio6);

        File f3 = new File ("29384");
        t1.createAndAddEpisode(f3, "Superman");
        File f4 = new File ("03302");
        t1.createAndAddEpisode(f4, "WonderWoman");
        File f5 = new File ("20239");
        t2.createAndAddEpisode(f5, "IronMan");
        File f6 = new File ("020294");
        t2.createAndAddEpisode(f6, "Hulk");
        File f7 = new File ("230493");
        t3.createAndAddEpisode(f7, "Falcon");
        File f8 = new File ("020294");
        t4.createAndAddEpisode(f4, "Wanda");
        sampleLibrary.addTVShow(t1);
        sampleLibrary.addTVShow(t2);
        sampleLibrary.addTVShow(t3);
        sampleLibrary.addTVShow(t4);

        /** generate a Watchlist of the first episodes of all TV shows from the WarnerBrothers studio
         * that are in either English or French, using the enhanced filters **/
        WatchList w1 = sampleLibrary.generateWatchList("FilteredList", conjunctionFilter);

        Episode sampleEpisode = (Episode) w1.next();

        /**
         * Q2:
         */


        /**
         * Make TVShow
         */
        String Title7 = "Star Wars";
        Language lang7 = Language.ENGLISH;
        String Studio7 = "Lucasfilm";
        TVShow t5 = new TVShow(Title7, lang7, Studio7);

        /**
         * Add an episode to the TVShow created
         */
        File f9 = new File("23455");
        String pTitle = "Empire Strikes Back";
        t5.createAndAddEpisode(f9, pTitle);

        /**
         * Set prototype to this newly added episode
         */
        t5.setPrototype(0);


        /**
         * Adds prototype with newly specified file and title to episode list
         */

        File newFile = new File("34556");
        String newTitle = "Revenge of the Sith";

        t5.addPrototypeEpisode(newFile, newTitle);;




    }


}
