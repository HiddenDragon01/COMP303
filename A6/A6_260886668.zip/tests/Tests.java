import org.junit.Before;
import java.lang.reflect.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

public class Tests {

    MyProgram p1;
    MyProgram p2;
    Robot WallE;
    Robot WallE2;

    /**
     * Implement a stub and a concrete class to be tested later
     */

    static class StubAction implements Action
    {

        @Override
        public void execute(Robot pRobot) {
            pRobot.updateBatteryLevel();
        }

        @Override
        public double getDistance() {
            return 0;
        }

        @Override
        public double numCompacted() {
            return 20.0;
        }
    }

    static class ConcreteHybridAction implements Action{

        /**
         * Define a "hybrid action" using the Decorator
         * design pattern.
         * A hybrid action could be either a basic action
         * or a complex action. When aAction = null it is
         * a basic action, and otherwise, it is a complex
         * action
         */

        Action aAction;


        public boolean isComplexAction() {

            return aAction != null;

        }

        public double numCompacted() {
            if (!isComplexAction()) {
                return 0;
            }

            return aAction.numCompacted();
        }

        /**
         * Log information and then execute the action
         */
        public void execute(Robot pRobot) {

            if (pRobot.getBatteryCharge() <= 5) {
                pRobot.rechargeBattery();
            }

            if (!isComplexAction()) {
                return;
            }

            String actionType = aAction.getClass().getSimpleName();
            int batteryLevel = pRobot.getBatteryCharge();
            System.out.print(actionType + " action performed, battery level is " + batteryLevel + "\n");

            aAction.execute(pRobot);
        }

        public double getDistance() {

            if (!isComplexAction()) {
                return 0;
            }

            return aAction.getDistance();
        }




    }

    /**
     * Initialize variables
     */
    @BeforeEach
    public void init() {

        /**
         * Define the robot and a program using
         * actions listed in assignment
         */

        WallE = new WallE();
        WallE2 = new WallE();

        HybridAction complexAction = new CounterClockwiseAction(new ClockWiseAction(new MoveForwardAction(null, 3.0)));

        List<Action> l1 = new ArrayList<>();
        l1.add(complexAction);
        l1.add(new MoveForwardAction(null, 4.0));
        l1.add(new OpenGripper());
        l1.add(new GrabAction(null));
        l1.add(new CompactAction(null));
        l1.add(new GrabAction(null));
        l1.add(new CompactAction(null));
        l1.add(new GrabAction(null));
        l1.add(new OpenGripper());

        p1 = new MyProgram(l1, WallE);

        List<Action> l2 = new ArrayList<>();

        l2.add(new OpenGripper());

        p2 = new MyProgram(l2, WallE2);


    }

    /**
     * Distance calculated should be 7.0
     */
    @Test
    public void checkDistance() {

        double distance = p1.accept(new CalculateDistance());
        assertEquals(distance, 7.0);
    }

    /**
     * Number compacted calculated should be 2.0
     */
    @Test
    public void checkNumberCompacted() {
        double numCompacted = p1.accept(new NumberCompacted());
        assertEquals(numCompacted, 2.0);
    }

    /**
     * Battery charge should not be full at the end of the program
     */
    @Test
    public void checkBattery() {

        assertTrue(WallE.getBatteryCharge() != 100);
    }

    /**
     * Run the battery down below 5. Then, execute the program.
     * Since the battery level is below 5, it should be greater
     * than 5 after running the program
     */
    @Test
    public void checkRecharged() {
        while (WallE.getBatteryCharge() > 5) {
            WallE.updateBatteryLevel();
        }
        p1.execute(WallE);
        assertTrue(WallE.getBatteryCharge() > 5);
    }

    /**
     * Run the battery below 10. After that, execute the program.
     * Since a "NewAction" is in the program, before that action is
     * executed, the battery should be recharged (so should
     * definitely be greater than 50)
     */
    @Test
    public void checkRechargedAfterNewAction() {

        while (WallE2.getBatteryCharge() > 10) {
            WallE2.updateBatteryLevel();
        }

        p2.execute(WallE2);
        assertTrue(WallE2.getBatteryCharge() > 50);

    }

    /**
     * Set the "aAction" field of our concrete class to the stub created using reflection.
     * Then, check to see if the number compacted is 20.0.
     */
    @Test
    public void testStudAction() throws NoSuchFieldException, IllegalAccessException {
        Field strategyField = ConcreteHybridAction.class.getDeclaredField("aAction");
        strategyField.setAccessible(true);
        Action strategy = new StubAction();
        Action concreteHybrid = new ConcreteHybridAction();
        strategyField.set(concreteHybrid, strategy);
        assertEquals(concreteHybrid.numCompacted(), 20.0);
    }


}
