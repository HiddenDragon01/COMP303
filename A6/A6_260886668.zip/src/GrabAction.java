public class GrabAction extends HybridAction {

    public GrabAction(Action pAction) {
        super(pAction);
    }

    /**
     * Action which grabs an action by
     * extending the arm, closing the gripper,
     * and retracting the arm
     *
     * @param pRobot
     *             the robot to call grab on
     * @pre arm isn't already extended
     */
    @Override
    public void execute(Robot pRobot) {
        super.execute(pRobot);
        assert pRobot.getArmState() == Robot.ArmState.RETRACTED;
        pRobot.extendArm();
        assert pRobot.getGripperState() == Robot.GripperState.OPEN;
        pRobot.closeGripper();
        assert pRobot.getArmState() == Robot.ArmState.EXTENDED;
        pRobot.retractArm();

    }
}
