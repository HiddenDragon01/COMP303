public abstract class HybridAction implements Action{

    /**
     * Define a "hybrid action" using the Decorator
     * design pattern.
     * A hybrid action could be either a basic action
     * or a complex action. When aAction = null it is
     * a basic action, and otherwise, it is a complex
     * action
     */

    Action aAction;

    public HybridAction(Action pAction) {

        aAction = pAction;

    }


    public boolean isComplexAction() {

        return aAction != null;

    }

    public double numCompacted() {
        if (!isComplexAction()) {
            return 0;
        }

        return aAction.numCompacted();
    }

    /**
     * Check battery, log information, and then execute the action
     * If this is a basic action, there is no need to execute further
     * actions
     *
     * @param pRobot
     *              the robot to execute the action on
     */
    public void execute(Robot pRobot) {

        if (pRobot.getBatteryCharge() <= 5) {
            pRobot.rechargeBattery();
        }

        if (!isComplexAction()) {
            return;
        }

        String actionType = aAction.getClass().getSimpleName();
        int batteryLevel = pRobot.getBatteryCharge();
        System.out.print(actionType + " action performed, battery level is " + batteryLevel + "\n");

        aAction.execute(pRobot);
    }

    public double getDistance() {

        if (!isComplexAction()) {
            return 0;
        }

        return aAction.getDistance();
    }




}
