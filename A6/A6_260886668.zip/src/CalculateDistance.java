import java.util.List;
public class CalculateDistance implements Visitor {

    /**
     * Class used to calculate the distance moved by the robot
     * using the Visitor design pattern
     */


    /**
     * If visiting a program, return the sum of the distances from
     * each visited action in the program
     *
     * @param pProgram
     *              the program to calculate the total distance on
     * @return the total distance in the program
     */
    @Override
    public double visit(Program pProgram) {
        double distance = 0;
        List<Action> Actions = pProgram.getActions();
        for (Action pAction : Actions) {
            distance += visit(pAction);
        }
        return distance;
    }


    /**
     * When visiting an action, simply return the distance associated
     * with that action
     * @param aAction
     *             the action to calculate the distance on
     * @return the total distance in the action
     */
    @Override
    public double visit(Action aAction) {

        double distance = aAction.getDistance();
        return distance;
    }



}

