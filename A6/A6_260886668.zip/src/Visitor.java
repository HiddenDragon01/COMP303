public interface Visitor {

    /**
     * Visitor interface can visit a program
     * or an action
     */

    public double visit(Program pProgram);
    public double visit(Action aAction);

}

