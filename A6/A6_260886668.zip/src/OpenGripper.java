public class OpenGripper extends NewAction{

    /**
     * Since this is a new action, the battery is recharged
     * before executing the action. Then, the gripper is opened
     * and the battery level is updated
     *
     * @param pRobot
     *             the Robot to call open and update battery on
     * @pre gripper isn't already open
     * @pre arm is retracted
     */
    @Override
    public void execute(Robot pRobot) {
        super.execute(pRobot);
        assert pRobot.getGripperState() != Robot.GripperState.OPEN &&
                pRobot.getArmState() == Robot.ArmState.RETRACTED;
        pRobot.openGripper();
        pRobot.updateBatteryLevel();
    }




}
