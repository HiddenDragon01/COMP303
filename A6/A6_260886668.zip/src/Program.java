import java.util.List;

public abstract class Program {

    /**
     * Define abstraction for a program with relevant fields and methods
     */

    private List<Action> aActions;

    public Program(List<Action> pActions) {
        aActions = pActions;
    }

    public List<Action> getActions() {
        return aActions;
    }

    public void addAction(Action pAction) {
        aActions.add(pAction);
    }

    public abstract void execute(Robot pRobot);

}
