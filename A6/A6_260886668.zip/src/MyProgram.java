import java.util.List;

public class MyProgram extends Program implements Visitable {

    /**
     * Runs program upon initiation
     */
    public MyProgram(List<Action> pActions, Robot pRobot) {

        super(pActions);
        execute(pRobot);
    }


    /**
     * To execute a program, first execute the actions
     * in the program and then log information
     * about the action
     * If there is a complex action in the program, log that action
     * as well
     *
     * @param pRobot
     *             the robot to run the program on
     */
    @Override
    public void execute(Robot pRobot) {

        for (Action aAction: super.getActions()) {
            /**
             * If an exception occurs, then stop executing further actions
             */
            try {

                int batteryLevel = pRobot.getBatteryCharge();
                if (aAction instanceof HybridAction) {
                    if (((HybridAction) aAction).isComplexAction()) {
                        System.out.print("Complex action performed, battery level is " + batteryLevel + "\n");
                    }
                }

                aAction.execute(pRobot);
                String actionType = aAction.getClass().getSimpleName();
                System.out.print(actionType + " action performed, battery level is " + batteryLevel + "\n");
            } catch (AssertionError e) {
                break;
            }
        }
    }

    /**
     * Allows the visitor to visit this program
     */
    @Override
    public double accept(Visitor aVisitor) {
        return aVisitor.visit(this);
    }

}

