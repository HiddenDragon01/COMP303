public interface Visitable {

    /**
     * Visitable interface has one method to
     * accept a visitor
     */

    public double accept(Visitor aVisitor);
}

