public class EmptyAction extends HybridAction {

    public EmptyAction(Action pAction) {
        super(pAction);
    }

    /**
     * Action which empties the compactor
     *
     * @param pRobot
     *              the robot to call empty on
     * @pre compactor isn't already empty
     */
    @Override
    public void execute(Robot pRobot) {
        super.execute(pRobot);
        assert pRobot.getCompactorLevel() > 0;
        pRobot.emptyCompactor();
    }

}
