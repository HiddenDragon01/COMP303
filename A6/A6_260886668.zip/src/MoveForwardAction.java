public class MoveForwardAction extends HybridAction {

    private double aDistance;

    public MoveForwardAction(Action pAction, double pDistance) {
        super(pAction);
        aDistance = pDistance;
    }

    /**
     * Action which moves forward by an amount set by
     * the client
     *
     * @param pRobot
     *             the robot to move forward
     * @pre pDistance >= 0
     * @pre arm is retracted
     */

    @Override
    public void execute(Robot pRobot) {
        super.execute(pRobot);
        assert pRobot.getArmState() == Robot.ArmState.RETRACTED && aDistance >= 0;
        pRobot.moveRobot(aDistance);
    }

    public double getDistance() {
        return aDistance + super.getDistance();
    }


}
