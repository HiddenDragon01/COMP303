public interface Action {

    /**
     * Define abstraction for an action with relevant methods
     */

    public void execute(Robot pRobot);
    public double getDistance();
    public double numCompacted();
}
