public class CompactAction extends HybridAction {

    public CompactAction(Action pAction) {
        super(pAction);
    }


    /**
     * Action which compacts an object
     * @param pRobot
     *              the robot to call compact on
     * @pre gripper holds an object
     * @pre compactor contains less than 10 objects
     * @post gripper is open
     */
    public void execute(Robot pRobot) {
        super.execute(pRobot);
        assert pRobot.getCompactorLevel() < 10
                && pRobot.getGripperState() == Robot.GripperState.HOLDING_OBJECT;
        pRobot.compact();
    }

    /**
     * Action adds 1 to the number of compacted objects
     */
    public double numCompacted() {
        return 1 + super.numCompacted();
    }
}
