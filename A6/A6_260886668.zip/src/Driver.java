import java.util.ArrayList;
import java.util.List;

public class Driver {

    public static void main(String[] args) {

        /**
         * Define the robot and a program using
         * actions listed in assignment
         */

        Robot WallE = new WallE();

        HybridAction complexAction = new CounterClockwiseAction(new ClockWiseAction(new MoveForwardAction(null, 3.0)));

        List<Action> l1 = new ArrayList<>();
        l1.add(complexAction);
        l1.add(new MoveForwardAction(null, 4.0));
        l1.add(new OpenGripper());
        l1.add(new GrabAction(null));
        l1.add(new CompactAction(null));
        l1.add(new GrabAction(null));
        l1.add(new CompactAction(null));
        l1.add(new GrabAction(null));
        l1.add(new OpenGripper());

        MyProgram p1 = new MyProgram(l1, WallE);

        /**
         * Now calculate the distance
         * and number of objects compacted
         */

        double distance = p1.accept(new CalculateDistance());
        double numCompacted = p1.accept(new NumberCompacted());
        System.out.println("Distance: " + distance + " , number compacted: " + numCompacted);



    }
}
