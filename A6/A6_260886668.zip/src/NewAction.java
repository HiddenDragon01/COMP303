public abstract class NewAction implements Action {

    /**
     * Every time a new action is called, the battery is recharged
     * before the execution of the action
     *
     * @param pRobot
     *              the robot to call recharge on
     */
    public void execute(Robot pRobot) {
        pRobot.rechargeBattery();
    }


    public double getDistance() {
        return 0;
    }


    public double numCompacted() {
        return 0;
    }

}
