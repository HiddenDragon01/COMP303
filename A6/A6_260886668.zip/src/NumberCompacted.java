import java.util.List;

public class NumberCompacted implements Visitor {

    /**
     * This class calculates the number of compacted
     * objects in a given program using the Visitor design pattern
     */

    /**
     * To calculate the number of compacted objects in a program,
     * sum the number of compacted objects in each action
     *
     * @param pProgram
     *               the program to calculate the total compacted objects on
     */
    @Override
    public double visit(Program pProgram) {
        int numCompacted = 0;
        List<Action> Actions = pProgram.getActions();
        for (Action Action : Actions) {
            numCompacted += visit(Action);
        }
        return numCompacted;
    }


    /**
     * When visiting an action, simply return the number compacted associated
     * with that action
     *
     * @param aAction
     *              the action to calculate the total compacted objects on
     */
    @Override
    public double visit(Action aAction) {


        double numCompacted = aAction.numCompacted();


        return numCompacted;
    }


}
