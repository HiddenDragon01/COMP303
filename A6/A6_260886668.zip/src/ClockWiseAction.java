public class ClockWiseAction extends HybridAction {


    public ClockWiseAction(Action pAction) {
        super(pAction);
    }

    /**
     * Action which turns the robot by -90 degrees
     *
     * @param pRobot
     *              the robot to turn
     * @pre arm is retracted
     */
    @Override
    public void execute(Robot pRobot) {
        super.execute(pRobot);
        assert pRobot.getArmState() == Robot.ArmState.RETRACTED;
        pRobot.turnRobot(-90.0);
    }



}
