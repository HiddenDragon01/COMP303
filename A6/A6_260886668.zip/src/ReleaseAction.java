public class ReleaseAction extends HybridAction {


    public ReleaseAction(Action pAction) {
        super(pAction);
    }

    /**
     * The release action consists of opening the gripper
     *
     * @param pRobot
     *             the robot to call release on
     * @pre gripper isn't already open
     * @pre arm is retracted
     */
    @Override
    public void execute(Robot pRobot) {
        super.execute(pRobot);
        assert pRobot.getGripperState() != Robot.GripperState.OPEN &&
                pRobot.getArmState() == Robot.ArmState.RETRACTED;
        pRobot.openGripper();
    }



}
