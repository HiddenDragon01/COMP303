public enum Language {

    ENGLISH,
    FRENCH,
    SPANISH,
    LATIN,
    ANCIENT_GREEK,
    KLINGON
}

