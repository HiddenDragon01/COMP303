import java.io.File;
public class Driver {

    public static void main(String[] args) {
        /**
         * Q1 Tests
         */

        // Create only instance of library
        Library singLib = Library.getSingLibrary("Lib1");

        // Since only one instance is allowed, secondLib should == singLib
        Library secondLib = Library.getSingLibrary("Lib2");
        // Should return true
        System.out.println("Checking equality between libraries: " + (singLib == secondLib));
        // The name should be Lib1
        System.out.println("Name of library is: " + secondLib.getName());
        // Optional ID should be empty now
        System.out.println("Optional ID: " + singLib.getEmailID());
        singLib.setEmailID("VladimirPutin@Iceberry.com");
        // Optional ID should not be empty now
        System.out.println("New optional ID: " + singLib.getEmailID());
        // Name should change now to "Lib3"
        singLib.setName("Lib3");
        System.out.println("New name: " + singLib.getName());


        /**
         * Q2 Tests
         */


        // Movie tests:

        // Create first Movie:

        File f1 = new File ("12345");
        String Title1 = "Zelda";
        Language lang1 = Language.FRENCH;
        String Studio1 = "Mario";

        // Should notice movie does not exist with this title and should create new movie with the parameters

        Movie m1 = Movie.getMovie(f1, Title1, lang1, Studio1);

        // Create second Movie:

        File f2 = new File ("54321");
        String Title2 = "Zelda";
        Language lang2 = Language.ENGLISH;
        String Studio2 = "Luigi";

        // Should notice movie does exist with this title and should return m1. Thus m1 == m2.

        Movie m2 = Movie.getMovie(f2, Title2, lang2, Studio2);

        System.out.println("Checking equality between movies: " + (m1 == m2));

        // TVShow tests:

        // Create first TVShow:

        String Title3 = "Lupin";
        Language lang3 = Language.FRENCH;
        String Studio3 = "Assane";

        // Should notice TVShow does not exist with this title and should create new TVShow with the parameters

        TVShow t1 = TVShow.getTVShow(Title3, lang3, Studio3);

        // Create second TVShow:

        String Title4 = "Lupin";
        Language lang4 = Language.ENGLISH;
        String Studio4 = "Claire";

        // Should notice TVShow does exist with this title and should return t1. Thus t1 == t2.

        TVShow t2 = TVShow.getTVShow(Title4, lang4, Studio4);

        System.out.println("Checking equality between TVShows: " + (t1 == t2));

        /**
         * Q3 Tests
         */

        // Make first watchlist:

        WatchList w1 = new WatchList("Netflix");
        w1.addWatchable(t1);

        // Make second watchlist:

        WatchList w2 = new WatchList("Harry Potter");
        w2.addWatchable(t2);



        // Since both watchlists have the same object (t1 == t2), they should be equal
        System.out.println("Checking equality between watchlists: " + w1.equals(w2));

       w1.addWatchable(t2);

        // Now, since they aggregate different objects, they should NOT be equal

       System.out.println("Checking equality again between watchlists: " + w1.equals(w2));




    }
}
