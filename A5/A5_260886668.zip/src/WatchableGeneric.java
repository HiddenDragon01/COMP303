import java.util.HashMap;
import java.util.Map;


/**
 * This abstract class contains several methods shared in common among Watchable implementations.
 * Through inheritance, these methods will save us from writing duplicated code.
 * There exists also an abstract method, isValid(), which is common to Watchable implementations
 * but may be implemented differently
 */

public abstract class WatchableGeneric implements Watchable {

    private String aTitle;
    private Language aLanguage;
    private String aStudio;
    private Map<String, String> aTags = new HashMap<>();

    /**
     * Getters and setters defined below.
     * Must implement setters, or else child class has no way of setting fields in
     * parent class
     */

    public String getTitle() {
        return aTitle;
    }

    public void setTitle(String pTitle) {
        aTitle = pTitle;
    }

    public Language getLanguage() {
        return aLanguage;
    }

    public void setLanguage(Language pLanguage) {
        aLanguage = pLanguage;
    }

    public String getStudio() {
        return aStudio;
    }

    public void setStudio(String pStudio) {
        aStudio = pStudio;
    }


    public String setInfo(String pKey, String pValue) {
        assert pKey != null && !pKey.isBlank();
        if (pValue == null) {
            return aTags.remove(pKey);
        }
        else {
            return aTags.put(pKey, pValue);
        }
    }

    public boolean hasInfo(String pKey) {
        assert pKey != null && !pKey.isBlank();
        return aTags.containsKey(pKey);
    }

    public String getInfo(String pKey) {
        assert hasInfo(pKey);
        return aTags.get(pKey);
    }

    /**
     * Must provide setInfo() and getInfo() overloading in order to access and set private fields
     * to make a clone
     */

    protected void setInfo(HashMap<String,String> pTags) {
        aTags = pTags;
    }

    protected HashMap<String, String> getInfo() {
        return (HashMap<String, String>) aTags;
    }

    public abstract boolean isValid();


}
