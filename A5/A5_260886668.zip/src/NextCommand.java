public class NextCommand implements Command{

    int aNext;
    WatchList aWatchList;

    public NextCommand(WatchList pWatchlist, int pNext) {
        aNext = pNext;
        aWatchList = pWatchlist;
    }

    @Override
    public void undo() {
        aWatchList.setNextCommand(aNext - 1);
    }

    @Override
    public void redo() {
        aWatchList.setNextCommand(++aNext);
    }
}
