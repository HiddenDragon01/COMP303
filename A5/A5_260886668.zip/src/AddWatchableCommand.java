/**
 * Supports adding an removing a Watchable from a list
 */
public class AddWatchableCommand implements Command {

    WatchList aWatchList;
    Watchable aWatchable;


    public AddWatchableCommand(WatchList pWatchList, Watchable pWatchable) {

        aWatchList = pWatchList;
        aWatchable = pWatchable;

    }

    @Override
    public void undo() {
        aWatchList.removeWatchableCommand(-1);

    }

    @Override
    public void redo() {

        aWatchList.addWatchableCommand(-1, aWatchable);

    }
}
