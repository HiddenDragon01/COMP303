import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

/**
 * Represents a sequence of watchables to watch in FIFO order.
 */
public class WatchList implements Bingeable<Watchable> {

    /**
     * Two stacks to keep track of redo's and undo's
     */
    private Stack<Command> aUndoStack = new Stack<Command>();
    private Stack<Command> aRedoStack = new Stack<Command>();

    Command lastCommand;

    private final List<Watchable> aList = new LinkedList<>();

    private boolean calledUndo = false;


    /**
     * Added a "last watched" field.
     */
    private Watchable aLastWatched;

    private String aName;
    private int aNext;

    /**
     * Creates a new empty watchlist.
     *
     * @param pName
     *            the name of the list
     * @pre pName!=null;
     */
    public WatchList(String pName) {
        assert pName != null;
        aName = pName;
        aNext = 0;
    }

    public String getName() {
        return aName;
    }

    /**
     * Changes the name of this watchlist, add this command to the undo stack, clear the redo stack
     * , and update calledUndo
     * @param pName
     *            the new name
     * @pre pName!=null;
     */
    public void setName(String pName) {
        assert pName != null;
        aUndoStack.add(new SetNameCommand(this, pName, aName));
        lastCommand = new SetNameCommand(this, pName, aName);
        aRedoStack.clear();
        calledUndo = false;
        aName = pName;
    }



    /**
     * Adds a watchable at the end of this watchlist, add this command to the undo stack, update the last command
     * and calledUndo, and clear the redo stack
     *
     * @param pWatchable
     *            the watchable to add
     * @pre pWatchable!=null;
     */
    public void addWatchable(Watchable pWatchable) {
        assert pWatchable != null;
        aList.add(pWatchable);
        /**
         *  Store a reference to this watch list in the Watchable so when watch() is called later for the
         *  Watchable, it will know to update this WatchList
         */
        pWatchable.addWatchList(this);
        aUndoStack.add(new AddWatchableCommand(this, pWatchable));
        lastCommand = new AddWatchableCommand(this, pWatchable);
        calledUndo = false;
        aRedoStack.clear();
    }

    /**
     * Retrieves and removes the Watchable at the specified index, add this command to the undo stack,
     * update the last command and calledUndo, and clear the redo stack
     *
     *
     * @param pIndex
     *            the position of the Watchable to remove
     * @pre pIndex < getTotalCount() && pIndex >= 0
     */
    public Watchable removeWatchable(int pIndex) {
        assert pIndex < aList.size() && pIndex >= 0;
        if (aNext > pIndex) {
            aNext--;
        }

        Watchable removed = aList.remove(pIndex);
        aUndoStack.add(new RemoveWatchableCommand(this, pIndex, removed));
        lastCommand = new RemoveWatchableCommand(this, pIndex, removed);
        calledUndo = false;
        aRedoStack.clear();
        return removed;

    }

    /**
     * @return the total number of valid watchable elements
     */
    public int getValidCount() {
        int count = 0;
        for (Watchable item : aList) {
            if (item.isValid()) {
                count++;
            }
        }
        return count;
    }

    @Override
    public int getTotalCount() {
        return aList.size();
    }

    @Override
    public int getRemainingCount() {
        return aList.size() - aNext;
    }

    /**
     *  Retrieves the Watchable at the aNext, add this command to the undo stack,
     *  update the last command and calledUndo, and clear the redo stack
     */
    @Override
    public Watchable next() {
        assert getRemainingCount() > 0;
        Watchable next = aList.get(aNext);
        aNext++;
        if (aNext >= aList.size()) {
            aNext = 0;
        }

        aUndoStack.add(new NextCommand(this, aNext));
        lastCommand = new NextCommand(this, aNext);
        calledUndo = false;
        aRedoStack.clear();

        return next;
    }

    /**
     *  Sets aNext to 0, add this command to the undo stack,
     *  update the last command and calledUndo, and clear the redo stack
     */
    @Override
    public void reset() {

        aUndoStack.add(new ResetCommand(this, aNext));
        lastCommand = new ResetCommand(this, aNext);
        calledUndo = false;
        aRedoStack.clear();

        aNext = 0;
    }

    @Override
    public Iterator<Watchable> iterator() {
        return Collections.unmodifiableList(aList).iterator();
    }

    /**
     * Updates the last watched field with the correct Watchable object
     */
    public void setLastWatched(Watchable pLastWatched) {
        assert pLastWatched != null;
        aLastWatched = pLastWatched;
    }


    /**
     * Returns the last Watchable object watched.
     */
    public Watchable lastWatched() {
        assert aLastWatched != null;
        return aLastWatched;

    }

    /**
     * Change the name of the WatchList without affecting the stacks
     */
    protected void setNameCommand(String pName) {
        assert pName != null;
        aName = pName;
    }

    /**
     * If index == -1, then add the Watchable to the end of the list
     * Else, add the watchable at index
     */
    protected void addWatchableCommand(int index, Watchable pWatchable) {

        assert pWatchable != null;
        if (index == - 1) {
            aList.add(pWatchable);
        } else {

            aList.add(index, pWatchable);

        }
    }

    /**
     * If index == -1, then remove the last element
     * Else, remove the element at index
     */
    protected void removeWatchableCommand(int pIndex) {

        assert pIndex < aList.size() && pIndex >= 0;


        if (pIndex == -1) {
            aList.remove(aList.size() - 1);
        } else {

            aList.remove(pIndex);

        }

    }

    protected void setNextCommand(int pNext) {

        aNext = pNext;
    }

    /**
     * If the undo stack is not empty, then call undo on the command at the top of the stack.
     * Then, pop that command off the undo stack and move it to the redo stack
     */
    public void undo() {

        calledUndo = true;

        if (aUndoStack.empty()) {
            return;
        }


        aUndoStack.peek().undo();
        aRedoStack.add(aUndoStack.pop());
    }

    /**
     * If undo was not called recently, repeat the last command.
     * If redo stack is empty, return.
     * Else, call redo on the command at the top of the redo stack.
     * Then, pop that command off the redo stack and move it to the undo stack
     */
    public void redo() {

        if (!calledUndo) {

            if (lastCommand == null) {
                return;
            }

            lastCommand.redo();
        } else {

            if (aRedoStack.empty()) {
                return;
            }

            aRedoStack.peek().redo();
            aUndoStack.add(aRedoStack.pop());
        }

    }










}
