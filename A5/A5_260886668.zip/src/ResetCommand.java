public class ResetCommand implements Command {

    WatchList aWatchList;
    int aNext;

    public ResetCommand(WatchList pWatchList, int pNext) {
        aWatchList = pWatchList;
        aNext = pNext;
    }

    @Override
    public void undo() {
        aWatchList.setNextCommand(aNext);
    }

    @Override
    public void redo() {
        aWatchList.setNextCommand(0);
    }
}
