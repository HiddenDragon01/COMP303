/**
 * Command interface with two simple methods
 */

public interface Command {

    public void undo();
    public void redo();

}
