import java.io.File;
import java.util.*;

public class Driver {

    public static void main(String[] args) {


        /**
         * Create variables to use in tests
         */

        File f1 = new File ("12345");
        String Title1 = "Zelda";
        Language lang1 = Language.FRENCH;
        String Studio1 = "Mario";


        Movie m1 = new Movie(f1, Title1, lang1, Studio1);


        File f2 = new File ("54321");
        String Title2 = "Bowser";
        Language lang2 = Language.ENGLISH;
        String Studio2 = "Luigi";


        Movie m2 = new Movie (f2, Title2, lang2, Studio2);


        String Title3 = "Lupin";
        Language lang3 = Language.FRENCH;
        String Studio3 = "Assane";

        TVShow t1 = new TVShow(Title3, lang3, Studio3, new HashMap<String, String>());


        String Title4 = "Lupin";
        Language lang4 = Language.ENGLISH;
        String Studio4 = "Claire";

        TVShow t2 = new TVShow(Title4, lang4, Studio4, new HashMap<String, String>());

        File f3 = new File ("X Æ A-12");

        t1.createAndAddEpisode(f3, "Elon Musk");

        TVShow.Episode e1 = t1.getEpisode(1);

        WatchList w1 = new WatchList("Netflix");

        /**
         * Q1 Tests
         */

        w1.addWatchable(m1);
        w1.addWatchable(m2);
        w1.addWatchable(t1);
        w1.addWatchable(e1);

        t1.watch();

        /**
         * Last watched should be t1
         */

        Watchable LastWatched = w1.lastWatched();

        m1.watch();

        /**
         * Last watched should be m1
         */

        LastWatched = w1.lastWatched();

        e1.watch();

        /**
         * Last watched should be e1
         */

        LastWatched = w1.lastWatched();


        /**
         * Q2 Tests, should be able to use inheritance to call parent class methods
         */

        m1.setTitle("James");
        m2.setStudio("Hollywood");
        t1.setLanguage(Language.LATIN);

        /**
         * Q3 Tests
         */

        /**
         * Calling undo 4 times will remove m1, m2, t1, and e1 from w1's aList
         */
        w1.undo();
        w1.undo();
        w1.undo();
        w1.undo();

        /**
         * Calling redo twice will add back m1 and m2
         */
        w1.redo();
        w1.redo();

        w1.setName("Dark Lord");
        /**
         * Name of w1 should now be "Dark Lord"
         */

        w1.undo();
        /**
         * Name of w1 should now be "Netflix"
         */

        w1.redo();
        /**
         * Name of w1 should now be "Dark Lord"
         */

        /**
         * Remove m1 and add it back
         */
        w1.removeWatchable(0);
        w1.undo();

        /**
         * Right now, redo stack should contain the removeWatchable command
         * If we call redo, we should remove m1.
         * If we call redo again, the stack should be empty, so nothing should happen
         */

        w1.redo();
        w1.redo();

        w1.addWatchable(m1);

        /**
         * Right now, aNext should equal 0
         * If we call next(), aNext should equal 1
         * Calling redo after that, aNext should equal 2.
         * If we then call reset, aNext should be equal to 0 again
         * Undoing the reset command, aNext should be 1 again
         * Undoing the next command, aNext should be 0 again
         */

        Watchable nextWatchable = w1.next();
        w1.redo();
        w1.reset();
        w1.undo();
        w1.undo();



    }



}
