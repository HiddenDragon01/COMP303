/**
 * Supports setting the name and unsetting the name
 */
public class SetNameCommand implements Command {

    private WatchList aWatchList;
    private String aName;
    private String aLastName;

     public SetNameCommand(WatchList pWatchList, String pName, String pLastName) {

         aWatchList = pWatchList;
         aName = pName;
         aLastName = pLastName;

     }


    @Override
    public void undo() {

         aWatchList.setNameCommand(aLastName);

    }

    @Override
    public void redo() {
        aWatchList.setNameCommand(aName);
    }
}
