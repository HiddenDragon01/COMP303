public class RemoveWatchableCommand implements Command{

    private WatchList aWatchList;
    private int aIndex;
    Watchable aWatchable;

    /**
     * Initialize fields in constructor
     */
    public RemoveWatchableCommand(WatchList pWatchList, int pIndex, Watchable pWatchable) {
        aWatchList = pWatchList;
        aIndex = pIndex;
        aWatchable = pWatchable;
    }

    @Override
    public void undo() {
        aWatchList.addWatchableCommand(aIndex, aWatchable);
    }

    @Override
    public void redo() {
        aWatchList.removeWatchableCommand(aIndex);
    }
}
