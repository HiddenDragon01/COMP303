public interface Binge<T> extends Iterable<T>{
    void bingeAll();
    void bingeNumber(int amount);
}
