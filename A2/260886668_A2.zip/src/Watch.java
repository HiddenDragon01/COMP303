// Interface which allows client to watch something
public interface Watch {
    void watch();
}
