import java.util.List;


// Generate a WatchList with a random parameter T
public interface generateWatchList<T> {
    public WatchList generate(T item1);
}
